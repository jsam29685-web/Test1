import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../providers/scanner_provider.dart';
import '../widgets/signal_banner.dart';
import '../widgets/price_chart.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(scannerProvider);
    final scan = state.scanResult;

    final localFormat = DateFormat('HH:mm:ss (d MMM)');
    final utcFormat = DateFormat('HH:mm:ss UTC');

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.2),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: const Color(0xFFF59E0B), width: 1),
              ),
              child: const Text(
                'BTC/USD 15M',
                style: TextStyle(
                  color: Color(0xFFF59E0B),
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'BTC Zones Scanner',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: state.isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF38BDF8)),
                  )
                : const Icon(Icons.refresh, color: Color(0xFF38BDF8)),
            onPressed: state.isLoading ? null : () => ref.read(scannerProvider.notifier).runScan(),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: const Color(0xFF38BDF8),
        onRefresh: () => ref.read(scannerProvider.notifier).runScan(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Error banner
            if (state.errorMessage != null)
              Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF43F5E).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFF43F5E)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning_amber, color: Color(0xFFF43F5E)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        state.errorMessage!,
                        style: const TextStyle(color: Color(0xFFF43F5E), fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),

            // Top Status Card (Price, ATR, Session, Timestamps)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Coinbase Live BTC-USD',
                            style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            scan != null ? '$${scan.currentPrice.toStringAsFixed(1)}' : 'Loading...',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.5,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      // Session Pill
                      if (scan != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: scan.isLondonOrNYSession
                                ? const Color(0xFF10B981).withOpacity(0.2)
                                : const Color(0xFF64748B).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: scan.isLondonOrNYSession
                                  ? const Color(0xFF10B981)
                                  : const Color(0xFF64748B),
                            ),
                          ),
                          child: Text(
                            scan.activeSession,
                            style: TextStyle(
                              color: scan.isLondonOrNYSession
                                  ? const Color(0xFF10B981)
                                  : const Color(0xFF94A3B8),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const Divider(color: Color(0xFF334155), height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Wilder ATR (14)', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                            Text(
                              scan != null ? '$${scan.atr14.toStringAsFixed(1)}' : '--',
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Strong Confluences', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                            Text(
                              scan != null ? '${scan.strongZonesCount} Zones' : '--',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: Color(0xFFF59E0B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Last Scan Time', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                            Text(
                              scan != null
                                  ? localFormat.format(DateTime.fromMillisecondsSinceEpoch(scan.timestamp))
                                  : '--',
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
                            ),
                            if (scan != null)
                              Text(
                                utcFormat.format(DateTime.fromMillisecondsSinceEpoch(scan.timestamp, isUtc: true)),
                                style: const TextStyle(color: Color(0xFF64748B), fontSize: 10),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Signal Banner
            if (scan != null) SignalBanner(scanResult: scan),

            const SizedBox(height: 16),

            // Chart Card
            if (state.candles.isNotEmpty)
              Container(
                height: 280,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E293B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF334155)),
                ),
                child: PriceChartWidget(
                  candles: state.candles,
                  zones: scan?.zones ?? [],
                  signal: scan?.signal,
                ),
              ),

            const SizedBox(height: 16),

            // Nearest Confluence Zones Quick Preview
            if (scan != null && scan.zones.isNotEmpty) ...[
              const Text(
                'Nearest Key Confluence Zones',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 8),
              ...scan.zones.take(4).map((z) => Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: z.isStrong
                          ? const Color(0xFFF59E0B).withOpacity(0.08)
                          : const Color(0xFF1E293B),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: z.isStrong ? const Color(0xFFF59E0B) : const Color(0xFF334155),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                if (z.isStrong)
                                  const Padding(
                                    padding: EdgeInsets.only(right: 6),
                                    child: Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
                                  ),
                                Text(
                                  '$${z.low.toStringAsFixed(1)} - $${z.high.toStringAsFixed(1)}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: z.isStrong ? const Color(0xFFF59E0B) : Colors.white,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              z.levels.map((l) => l.id).join(' • '),
                              style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: z.isStrong
                                ? const Color(0xFFF59E0B).withOpacity(0.2)
                                : const Color(0xFF334155),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            '${z.levelCount} Levels',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: z.isStrong ? const Color(0xFFF59E0B) : const Color(0xFF94A3B8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}
