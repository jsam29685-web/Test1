import 'package:flutter/foundation.dart';
import 'package:workmanager/workmanager.dart';
import '../constants/trading_constants.dart';
import '../../main.dart';

class BackgroundService {
  static const String periodicTaskUniqueName = 'com.btczones.scanner.periodic';
  static const String oneOffTaskUniqueName = 'com.btczones.scanner.oneoff';

  static Future<void> initialize() async {
    await Workmanager().initialize(
      callbackDispatcher,
      isInDebugMode: kDebugMode,
    );
  }

  /// Schedules periodic background scanner task
  static Future<void> schedulePeriodicScan({int intervalMinutes = 15}) async {
    // WorkManager minimum periodic interval on Android is 15 minutes.
    // For smaller intervals (5, 10), Android will execute at minimum supported period (15m)
    // or trigger chained one-time work for tight intervals.
    final frequency = Duration(minutes: intervalMinutes < 15 ? 15 : intervalMinutes);

    await Workmanager().cancelByUniqueName(periodicTaskUniqueName);

    await Workmanager().registerPeriodicTask(
      periodicTaskUniqueName,
      'btc_zones_periodic_scan',
      frequency: frequency,
      constraints: Constraints(
        networkType: NetworkType.connected,
        requiresBatteryNotLow: false,
        requiresCharging: false,
        requiresDeviceIdle: false,
        requiresStorageNotLow: false,
      ),
      existingWorkPolicy: ExistingWorkPolicy.replace,
      backoffPolicy: BackoffPolicy.linear,
      backoffPolicyDelay: const Duration(minutes: 1),
    );

    debugPrint('Periodic WorkManager scan registered for every $intervalMinutes min');
  }

  /// Triggers an immediate one-off background scan
  static Future<void> triggerImmediateScan() async {
    await Workmanager().registerOneOffTask(
      oneOffTaskUniqueName,
      'btc_zones_one_off_scan',
      constraints: Constraints(networkType: NetworkType.connected),
      existingWorkPolicy: ExistingWorkPolicy.replace,
    );
  }

  static Future<void> cancelAll() async {
    await Workmanager().cancelAll();
  }
}
