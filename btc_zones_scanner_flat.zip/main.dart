import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workmanager/workmanager.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/services/notification_service.dart';
import 'core/services/background_service.dart';
import 'data/repositories/market_data_repository.dart';
import 'domain/services/strategy_engine.dart';
import 'presentation/screens/dashboard_screen.dart';
import 'presentation/screens/zones_screen.dart';
import 'presentation/screens/history_screen.dart';
import 'presentation/screens/settings_screen.dart';

/// Top-level callback dispatcher for Workmanager background execution.
/// Runs in an isolated background thread even if the app process is terminated.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      await NotificationService.initialize();

      final prefs = await SharedPreferences.getInstance();
      final filterSessions = prefs.getBool('filter_sessions') ?? true;
      final minRR = prefs.getDouble('min_rr') ?? 1.5;
      final maxSLinATR = prefs.getDouble('max_sl_atr') ?? 6.0;

      // 1. Fetch live 15m candles from Coinbase / Binance
      final repository = MarketDataRepository();
      final candles = await repository.fetch15mCandles();

      if (candles.length < 20) {
        await NotificationService.showSilentScanNotification(
          'Background scan: Insufficient candle data received.',
        );
        return Future.value(true);
      }

      // 2. Run Strategy Engine
      final engine = StrategyEngine();
      final result = engine.evaluate(
        candles: candles,
        filterSessions: filterSessions,
        minRiskReward: minRR,
        maxSLinATR: maxSLinATR,
      );

      // 3. Persist scan cache
      await prefs.setString('last_scan_cache', jsonEncode(result.toJson()));
      
      // Keep rolling scan history
      final historyList = prefs.getStringList('scan_history') ?? [];
      historyList.insert(0, jsonEncode(result.toJson()));
      if (historyList.length > 20) historyList.removeLast();
      await prefs.setStringList('scan_history', historyList);

      // 4. Issue Notifications
      if (result.verdict == 'TRADE' && result.signal != null) {
        await NotificationService.showTradeSignalNotification(result.signal!);
      } else {
        final notificationsEnabled = prefs.getBool('enable_notifications') ?? true;
        if (notificationsEnabled) {
          await NotificationService.showSilentScanNotification(
            'BTC \${result.currentPrice.toStringAsFixed(1)} | No trade (\${result.reason})',
          );
        }
      }

      return Future.value(true);
    } catch (e) {
      debugPrint('Background task error: $e');
      return Future.value(true);
    }
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize notifications
  await NotificationService.initialize();

  // Initialize Workmanager background engine
  await BackgroundService.initialize();

  runApp(
    const ProviderScope(
      child: BTCZonesScannerApp(),
    ),
  );
}

class BTCZonesScannerApp extends StatelessWidget {
  const BTCZonesScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BTC Zones Scanner',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF38BDF8),
          secondary: Color(0xFFF59E0B), // Strong Zone Gold
          surface: Color(0xFF1E293B),
          error: Color(0xFFF43F5E),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E293B),
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    DashboardScreen(),
    ZonesScreen(),
    HistoryScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        backgroundColor: const Color(0xFF1E293B),
        indicatorColor: const Color(0xFF38BDF8).withOpacity(0.2),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard, color: Color(0xFF38BDF8)),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.layers_outlined),
            selectedIcon: Icon(Icons.layers, color: Color(0xFFF59E0B)),
            label: 'Zones',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history, color: Color(0xFF38BDF8)),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings, color: Color(0xFF38BDF8)),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
