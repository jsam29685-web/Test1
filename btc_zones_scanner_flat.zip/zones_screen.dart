import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/scanner_provider.dart';
import '../widgets/zone_card.dart';

class ZonesScreen extends ConsumerWidget {
  const ZonesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(scannerProvider);
    final scan = state.scanResult;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Confluence Zones (17 Levels)'),
      ),
      body: scan == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF59E0B).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.5)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.star, color: Color(0xFFF59E0B)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Gold Zones indicate Strong Confluence (>= 3 institutional levels clustered within 2.0x ATR). Current ATR: $${scan.atr14.toStringAsFixed(1)}',
                          style: const TextStyle(fontSize: 12, color: Color(0xFFF59E0B)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                ...scan.zones.map((zone) => ZoneCard(
                      zone: zone,
                      currentPrice: scan.currentPrice,
                    )),
              ],
            ),
    );
  }
}
