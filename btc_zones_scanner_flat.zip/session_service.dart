class SessionInfo {
  final String sessionName;
  final bool isLondonOrNY;
  final bool isLondon;
  final bool isNewYork;

  SessionInfo({
    required this.sessionName,
    required this.isLondonOrNY,
    required this.isLondon,
    required this.isNewYork,
  });
}

class SessionService {
  static SessionInfo getCurrentSession(DateTime utcTime) {
    final minutes = utcTime.hour * 60 + utcTime.minute;

    const londonStart = 8 * 60; // 08:00 UTC
    const londonEnd = 16 * 60 + 30; // 16:30 UTC
    const nyStart = 13 * 60; // 13:00 UTC
    const nyEnd = 21 * 60; // 21:00 UTC

    final isLondon = minutes >= londonStart && minutes <= londonEnd;
    final isNewYork = minutes >= nyStart && minutes <= nyEnd;

    String name = 'Off Hours';
    if (isLondon && isNewYork) {
      name = 'London / New York Overlap';
    } else if (isLondon) {
      name = 'London Session';
    } else if (isNewYork) {
      name = 'New York Session';
    } else if (minutes < 8 * 60) {
      name = 'Asian Session';
    }

    return SessionInfo(
      sessionName: name,
      isLondonOrNY: isLondon || isNewYork,
      isLondon: isLondon,
      isNewYork: isNewYork,
    );
  }
}
