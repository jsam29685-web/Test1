import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../data/models/candle.dart';
import '../../data/models/zone.dart';
import '../../data/models/signal.dart';

class PriceChartWidget extends StatelessWidget {
  final List<Candle> candles;
  final List<ConfluenceZone> zones;
  final TradeSignal? signal;

  const PriceChartWidget({
    super.key,
    required this.candles,
    required this.zones,
    this.signal,
  });

  @override
  Widget build(BuildContext context) {
    if (candles.isEmpty) return const SizedBox();

    final recent = candles.length > 40 ? candles.sublist(candles.length - 40) : candles;
    final spots = recent.asMap().entries.map((e) => FlSpot(e.key.toDouble(), e.value.close)).toList();

    final prices = recent.map((c) => c.close).toList();
    final minPrice = prices.reduce((a, b) => a < b ? a : b);
    final maxPrice = prices.reduce((a, b) => a > b ? a : b);
    final padding = (maxPrice - minPrice) * 0.15;

    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (value) => const FlLine(
            color: Color(0xFF334155),
            strokeWidth: 0.8,
            dashArray: [4, 4],
          ),
        ),
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 65,
              getTitlesWidget: (value, meta) => Text(
                '$${value.toInt()}',
                style: const TextStyle(color: Color(0xFF64748B), fontSize: 10),
              ),
            ),
          ),
          bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        minY: minPrice - padding,
        maxY: maxPrice + padding,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: const Color(0xFF38BDF8),
            barWidth: 2,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: const Color(0xFF38BDF8).withOpacity(0.08),
            ),
          ),
        ],
      ),
    );
  }
}
