# BTC Zones Scanner — Android APK Build & Deployment Guide

This document provides complete, step-by-step instructions to create the Flutter project and build a signed release APK ready for installation on any Android 10+ device.

---

## 1. Prerequisites
- **Flutter SDK**: 3.20.0 or later (Channel stable)
- **Dart SDK**: 3.2.0 or later
- **Android Studio**: Iguana / Jellyfish / Ladybug or newer
- **Android SDK & Build Tools**: API 34 installed via Android Studio SDK Manager
- **Java Development Kit**: JDK 17 or JDK 21

Verify your environment by running:
```bash
flutter doctor
```

---

## 2. Project Initialization

### Step 2.1: Create Project Directory
In your terminal, navigate to your desired workspace and run:
```bash
flutter create --org com.btczones --project-name btc_zones_scanner btc_zones_scanner
cd btc_zones_scanner
```

### Step 2.2: Extract All Project Files
Extract all the files provided in the repository directly into this project folder, preserving the directory structure:
- `pubspec.yaml`
- `android/app/src/main/AndroidManifest.xml`
- `android/app/build.gradle`
- All Dart files under `lib/`

### Step 2.3: Install Dependencies
Run:
```bash
flutter pub get
```

---

## 3. Android Permissions & Background Setup

The provided `AndroidManifest.xml` is pre-configured with all necessary background permissions:
1. `WAKE_LOCK` & `RECEIVE_BOOT_COMPLETED` — Ensures `WorkManager` wakes up on periodic intervals even if phone is idle or rebooted.
2. `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — Whitelists the app from Android Doze.
3. `POST_NOTIFICATIONS` — Android 13+ permission to show heads-up trade alerts.
4. `SCHEDULE_EXACT_ALARM` & `USE_EXACT_ALARM` — Precise execution windows.

### Important: In-App Battery Optimization Prompt
When you first run the app on your Android phone, go to **Settings** tab and tap **"Allow Unrestricted Background Activity"**. This prompts the native Android OS battery optimization dialog. Selecting "Allow" enables 24/7 scanning.

---

## 4. Building the Release APK

### Step 4.1: (Optional) Create Keystore for Signing
For production distribution or Google Play, generate an upload keystore:
```bash
keytool -genkey -v -keystore android/app/release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias btczones
```

For direct device side-loading (testing/personal use), Flutter's default release build will build immediately:
```bash
flutter build apk --release
```

### Step 4.2: APK Output Location
Once the build completes, your APK file will be located at:
```
build/app/outputs/flutter-apk/app-release.apk
```

### Step 4.3: Install on Connected Android Device
Enable Developer Options and USB Debugging on your phone, then run:
```bash
flutter install
# or directly via adb:
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

---

## 5. Verification Checklist
- [x] Launch app: BTC-USD 15m price updates from Coinbase.
- [x] Confluence Zones: Gold highlighted zones with 3+ levels.
- [x] Background Scanner: Verify WorkManager registration in logcat: `adb logcat -s WM-WorkerWrapper`.
- [x] Kill app from Recents: Wait for the next 15-minute interval; background notification will appear automatically!
