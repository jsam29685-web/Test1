import 'package:permission_handler/permission_handler.dart';

class BatteryService {
  /// Checks if the app is exempted from battery optimizations
  static Future<bool> isExemptFromBatteryOptimizations() async {
    return await Permission.ignoreBatteryOptimizations.isGranted;
  }

  /// Prompts the user with system dialog to whitelist the app from battery killing
  static Future<bool> requestBatteryOptimizationExemption() async {
    final status = await Permission.ignoreBatteryOptimizations.request();
    return status.isGranted;
  }
}
