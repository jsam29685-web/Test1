import 'package:flutter/material.dart';
import '../../data/models/scan_result.dart';

class SignalBanner extends StatelessWidget {
  final ScanResult scanResult;

  const SignalBanner({super.key, required this.scanResult});

  @override
  Widget build(BuildContext context) {
    final signal = scanResult.signal;

    if (signal == null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF334155)),
        ),
        child: Row(
          children: [
            const Icon(Icons.radar, color: Color(0xFF38BDF8), size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'STATUS: NO ACTIVE TRADE SIGNAL',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF94A3B8)),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    scanResult.reason,
                    style: const TextStyle(fontSize: 12, color: Color(0xFFCBD5E1)),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    final isBuy = signal.direction == 'BUY';
    final color = isBuy ? const Color(0xFF10B981) : const Color(0xFFF43F5E);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(isBuy ? Icons.arrow_upward : Icons.arrow_downward, color: color, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    '🚨 VALID ${signal.direction} ${signal.setupType}',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: color),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'RR 1:${signal.riskReward.toStringAsFixed(2)}',
                  style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 13),
                ),
              ),
            ],
          ),
          const Divider(height: 20, color: Color(0xFF334155)),
          Row(
            children: [
              Expanded(
                child: _buildMetric('ENTRY', '$${signal.entryPrice.toStringAsFixed(1)}', Colors.white),
              ),
              Expanded(
                child: _buildMetric('STOP LOSS', '$${signal.stopLoss.toStringAsFixed(1)}', const Color(0xFFF43F5E)),
              ),
              Expanded(
                child: _buildMetric('TAKE PROFIT', '$${signal.takeProfit.toStringAsFixed(1)}', const Color(0xFF10B981)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Confluence Zone: ${signal.zoneLevels.join(" + ")} (${signal.isStrongZone ? "Strong Gold" : "Standard"})',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFFCBD5E1)),
          ),
        ],
      ),
    );
  }

  Widget _buildMetric(String label, String value, Color valColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 10, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(color: valColor, fontSize: 15, fontWeight: FontWeight.w800)),
      ],
    );
  }
}
