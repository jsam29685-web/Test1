import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/settings_provider.dart';
import '../../core/services/battery_service.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  bool _isBatteryExempt = false;

  @override
  void initState() {
    super.initState();
    _checkBattery();
  }

  Future<void> _checkBattery() async {
    final exempt = await BatteryService.isExemptFromBatteryOptimizations();
    if (mounted) setState(() => _isBatteryExempt = exempt);
  }

  Future<void> _requestBattery() async {
    final granted = await BatteryService.requestBatteryOptimizationExemption();
    if (mounted) {
      setState(() => _isBatteryExempt = granted);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            granted
                ? 'Battery optimization exemption granted! 24/7 background scanning active.'
                : 'Exemption was not granted. Background scanning may be throttled by Android.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scanner Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Battery optimization card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _isBatteryExempt
                  ? const Color(0xFF10B981).withOpacity(0.12)
                  : const Color(0xFFF59E0B).withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _isBatteryExempt ? const Color(0xFF10B981) : const Color(0xFFF59E0B),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      _isBatteryExempt ? Icons.battery_charging_full : Icons.battery_alert,
                      color: _isBatteryExempt ? const Color(0xFF10B981) : const Color(0xFFF59E0B),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _isBatteryExempt
                          ? 'Background Scanning Active (24/7)'
                          : 'Battery Optimization Enabled',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _isBatteryExempt ? const Color(0xFF10B981) : const Color(0xFFF59E0B),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  _isBatteryExempt
                      ? 'The app has exemption from Android Doze. WorkManager can scan reliably even when your screen is locked or app is closed.'
                      : 'Android aggressively kills background tasks. Request exemption to guarantee automated scanning.',
                  style: const TextStyle(fontSize: 12, color: Color(0xFFCBD5E1)),
                ),
                if (!_isBatteryExempt) ...[
                  const SizedBox(height: 12),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF59E0B),
                      foregroundColor: Colors.black,
                    ),
                    onPressed: _requestBattery,
                    child: const Text('Allow Unrestricted Background Activity'),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 24),
          const Text('Scan Frequency', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          Wrap(
            spacing: 8,
            children: [5, 10, 15, 30, 60].map((mins) {
              final isSelected = settings.intervalMinutes == mins;
              return ChoiceChip(
                label: Text('$mins min'),
                selected: isSelected,
                selectedColor: const Color(0xFF38BDF8),
                onSelected: (_) => notifier.setInterval(mins),
              );
            }).toList(),
          ),

          const SizedBox(height: 24),
          const Text('Filters & Strategy', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          SwitchListTile(
            title: const Text('London & NY Sessions Only'),
            subtitle: const Text('Filters out low-volatility Asian/Off-hours (08:00 - 21:00 UTC)'),
            value: settings.filterSessions,
            onChanged: (v) => notifier.toggleSessionFilter(v),
          ),

          SwitchListTile(
            title: const Text('Trade Notifications'),
            subtitle: const Text('Sound + vibration when valid TRADE setup triggers'),
            value: settings.enableNotifications,
            onChanged: (v) => notifier.toggleNotifications(v),
          ),

          SwitchListTile(
            title: const Text('Sound Alerts'),
            subtitle: const Text('Play audible chime on signal'),
            value: settings.soundAlerts,
            onChanged: (v) => notifier.toggleSoundAlerts(v),
          ),

          const SizedBox(height: 16),
          ListTile(
            title: const Text('Risk % (Display Only)'),
            subtitle: Text('${settings.riskPercentage.toStringAsFixed(1)}% of account capital per setup'),
            trailing: SizedBox(
              width: 140,
              child: Slider(
                value: settings.riskPercentage,
                min: 0.5,
                max: 5.0,
                divisions: 9,
                onChanged: (v) => notifier.setRiskPercentage(v),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
