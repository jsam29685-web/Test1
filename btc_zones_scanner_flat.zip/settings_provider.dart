import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/services/background_service.dart';

class SettingsState {
  final int intervalMinutes; // 5, 10, 15, 30, 60
  final bool enableNotifications;
  final bool soundAlerts;
  final bool filterSessions;
  final double minRiskReward;
  final double maxSLinATR;
  final double riskPercentage;

  SettingsState({
    required this.intervalMinutes,
    required this.enableNotifications,
    required this.soundAlerts,
    required this.filterSessions,
    required this.minRiskReward,
    required this.maxSLinATR,
    required this.riskPercentage,
  });

  SettingsState copyWith({
    int? intervalMinutes,
    bool? enableNotifications,
    bool? soundAlerts,
    bool? filterSessions,
    double? minRiskReward,
    double? maxSLinATR,
    double? riskPercentage,
  }) {
    return SettingsState(
      intervalMinutes: intervalMinutes ?? this.intervalMinutes,
      enableNotifications: enableNotifications ?? this.enableNotifications,
      soundAlerts: soundAlerts ?? this.soundAlerts,
      filterSessions: filterSessions ?? this.filterSessions,
      minRiskReward: minRiskReward ?? this.minRiskReward,
      maxSLinATR: maxSLinATR ?? this.maxSLinATR,
      riskPercentage: riskPercentage ?? this.riskPercentage,
    );
  }
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier()
      : super(
          SettingsState(
            intervalMinutes: 15,
            enableNotifications: true,
            soundAlerts: true,
            filterSessions: true,
            minRiskReward: 1.5,
            maxSLinATR: 6.0,
            riskPercentage: 1.0,
          ),
        ) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    state = state.copyWith(
      intervalMinutes: prefs.getInt('interval_minutes') ?? 15,
      enableNotifications: prefs.getBool('enable_notifications') ?? true,
      soundAlerts: prefs.getBool('sound_alerts') ?? true,
      filterSessions: prefs.getBool('filter_sessions') ?? true,
      minRiskReward: prefs.getDouble('min_rr') ?? 1.5,
      maxSLinATR: prefs.getDouble('max_sl_atr') ?? 6.0,
      riskPercentage: prefs.getDouble('risk_pct') ?? 1.0,
    );
  }

  Future<void> setInterval(int minutes) async {
    state = state.copyWith(intervalMinutes: minutes);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('interval_minutes', minutes);
    await BackgroundService.schedulePeriodicScan(intervalMinutes: minutes);
  }

  Future<void> toggleSessionFilter(bool value) async {
    state = state.copyWith(filterSessions: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('filter_sessions', value);
  }

  Future<void> toggleNotifications(bool value) async {
    state = state.copyWith(enableNotifications: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('enable_notifications', value);
  }

  Future<void> toggleSoundAlerts(bool value) async {
    state = state.copyWith(soundAlerts: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sound_alerts', value);
  }

  Future<void> setRiskPercentage(double value) async {
    state = state.copyWith(riskPercentage: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('risk_pct', value);
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsState>((ref) {
  return SettingsNotifier();
});
