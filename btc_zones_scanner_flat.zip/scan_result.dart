import 'zone.dart';
import 'signal.dart';

class ScanResult {
  final int timestamp;
  final double currentPrice;
  final double atr14;
  final String activeSession;
  final bool isLondonOrNYSession;
  final List<ConfluenceZone> zones;
  final int strongZonesCount;
  final TradeSignal? signal;
  final String verdict; // 'TRADE' or 'NO_TRADE'
  final String reason;

  ScanResult({
    required this.timestamp,
    required this.currentPrice,
    required this.atr14,
    required this.activeSession,
    required this.isLondonOrNYSession,
    required this.zones,
    required this.strongZonesCount,
    required this.signal,
    required this.verdict,
    required this.reason,
  });

  Map<String, dynamic> toJson() => {
    'timestamp': timestamp,
    'currentPrice': currentPrice,
    'atr14': atr14,
    'activeSession': activeSession,
    'isLondonOrNYSession': isLondonOrNYSession,
    'zones': zones.map((z) => z.toJson()).toList(),
    'strongZonesCount': strongZonesCount,
    'signal': signal?.toJson(),
    'verdict': verdict,
    'reason': reason,
  };

  factory ScanResult.fromJson(Map<String, dynamic> json) => ScanResult(
    timestamp: json['timestamp'] as int,
    currentPrice: (json['currentPrice'] as num).toDouble(),
    atr14: (json['atr14'] as num).toDouble(),
    activeSession: json['activeSession'] as String,
    isLondonOrNYSession: json['isLondonOrNYSession'] as bool,
    zones: (json['zones'] as List)
        .map((z) => ConfluenceZone.fromJson(z as Map<String, dynamic>))
        .toList(),
    strongZonesCount: json['strongZonesCount'] as int,
    signal: json['signal'] != null
        ? TradeSignal.fromJson(json['signal'] as Map<String, dynamic>)
        : null,
    verdict: json['verdict'] as String,
    reason: json['reason'] as String,
  );
}
